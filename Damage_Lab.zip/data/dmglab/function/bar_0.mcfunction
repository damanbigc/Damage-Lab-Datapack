$data modify entity @s text set value ["",{"text": "❤❤❤❤❤❤❤❤❤❤", "color": "#3a3a3a"},{"text":"\n$(hp) / 20 HP","color":"white"},{"text":"   $(hits) hit$(hs)","color":"gray"}]
