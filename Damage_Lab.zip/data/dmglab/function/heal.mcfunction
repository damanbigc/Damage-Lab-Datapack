function dmglab:init
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 0.25 1.6
particle minecraft:happy_villager ~ ~1 ~ 0.35 0.6 0.35 0 12 force
execute store result score @s dl.hp run data get entity @s Health 1000
