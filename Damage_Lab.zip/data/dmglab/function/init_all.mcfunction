execute as @e[type=minecraft:mannequin,tag=dl.dummy] run function dmglab:init
