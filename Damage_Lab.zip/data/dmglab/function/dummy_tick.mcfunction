execute store result score @s dl.hp run data get entity @s Health 1000
execute unless score @s dl.prev matches -2147483648.. run scoreboard players set @s dl.prev 1024000
execute if score @s dl.hp < @s dl.prev run function dmglab:hit
scoreboard players add @s dl.idle 1
execute if score @s dl.idle matches 60 if score @s dl.lost matches 1.. run function dmglab:heal
execute if score @s dl.hp matches ..512000 run function dmglab:heal
scoreboard players operation @s dl.prev = @s dl.hp
