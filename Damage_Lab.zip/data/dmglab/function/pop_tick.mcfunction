scoreboard players add @s dl.age 1
execute if score @s dl.age matches 2 run function dmglab:pop_grow with storage dmglab:tmp
execute if score @s dl.age matches 14 run data merge entity @s {start_interpolation:0,interpolation_duration:8,transformation:{translation:[0f,1.1f,0f],scale:[0f,0f,0f]}}
execute if score @s dl.age matches 23.. run kill @s
