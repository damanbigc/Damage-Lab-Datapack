$data modify entity @s text set value ["",{"text": "❤❤❤❤❤❤❤❤❤❤", "color": "#ff3b3b"},{"text":"\n$(hp) / 20 HP","color":"white"},{"text":"   $(hits) hit$(hs)","color":"gray"}]
