execute align xyz run function dmglab:build_here
