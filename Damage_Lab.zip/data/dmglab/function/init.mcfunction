data modify entity @s Health set value 1024f
scoreboard players set @s dl.prev 1024000
scoreboard players set @s dl.lost 0
scoreboard players set @s dl.hits 0
scoreboard players set @s dl.idle 0
team leave @s
data modify entity @s Glowing set value 0b
tag @s remove dl.ko
function dmglab:bar
