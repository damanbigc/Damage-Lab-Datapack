give @s minecraft:wooden_sword 1
give @s minecraft:iron_sword 1
give @s minecraft:diamond_sword 1
give @s minecraft:netherite_sword 1
give @s minecraft:netherite_sword[enchantments={"minecraft:sharpness":5},custom_name={text:"Sharpness V Sword",color:"aqua",italic:0b}] 1
give @s minecraft:netherite_axe 1
give @s minecraft:mace 1
give @s minecraft:mace[enchantments={"minecraft:density":5},custom_name={text:"Density V Mace",color:"aqua",italic:0b}] 1
give @s minecraft:mace[enchantments={"minecraft:breach":4},custom_name={text:"Breach IV Mace",color:"aqua",italic:0b}] 1
give @s minecraft:bow[enchantments={"minecraft:power":5}] 1
give @s minecraft:arrow 64
give @s minecraft:trident 1
give @s minecraft:wind_charge 64
