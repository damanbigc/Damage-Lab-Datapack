$summon minecraft:text_display ~$(rx) ~2.55 ~ {Tags:["dl.pop"],billboard:"center",alignment:"center",background:0,shadow:1b,see_through:0b,brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.2f,0.2f,0.2f]},text:{text:"-$(num)",color:"$(col)",bold:true}}
$data modify storage dmglab:tmp lastsc set value $(sc)
