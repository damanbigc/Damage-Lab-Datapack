$data modify entity @s text set value ["",{"text":"☠ KNOCKED OUT ☠","color":"red","bold":true},{"text":"\nin $(hits) hit$(hs)","color":"white","bold":false}]
