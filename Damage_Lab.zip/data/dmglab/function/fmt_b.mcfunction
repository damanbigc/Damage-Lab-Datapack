$data modify storage dmglab:tmp out set value "$(w).0$(f)"
