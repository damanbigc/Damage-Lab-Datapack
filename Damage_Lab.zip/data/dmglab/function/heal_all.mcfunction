execute as @e[type=minecraft:mannequin,tag=dl.dummy] at @s run function dmglab:heal
