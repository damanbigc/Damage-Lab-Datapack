scoreboard players operation @s dl.dmg = @s dl.prev
scoreboard players operation @s dl.dmg -= @s dl.hp
scoreboard players operation @s dl.lost += @s dl.dmg
scoreboard players add @s dl.hits 1
scoreboard players set @s dl.idle 0
scoreboard players operation #v dl.tmp = @s dl.dmg
scoreboard players add #v dl.tmp 5
scoreboard players operation #v dl.tmp /= #10 dl.tmp
function dmglab:fmt
data modify storage dmglab:tmp num set from storage dmglab:tmp out
data modify storage dmglab:tmp col set value "white"
data modify storage dmglab:tmp sc set value 1.5f
execute if score @s dl.dmg matches 4000.. run data modify storage dmglab:tmp col set value "yellow"
execute if score @s dl.dmg matches 8000.. run data modify storage dmglab:tmp col set value "gold"
execute if score @s dl.dmg matches 15000.. run data modify storage dmglab:tmp col set value "red"
execute if score @s dl.dmg matches 15000.. run data modify storage dmglab:tmp sc set value 2.2f
execute store result storage dmglab:tmp rx float 0.1 run random value -6..6
function dmglab:pop with storage dmglab:tmp
execute if score @s dl.lost matches 20000.. unless entity @s[tag=dl.ko] run function dmglab:ko
function dmglab:bar
