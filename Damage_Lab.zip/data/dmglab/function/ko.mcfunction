tag @s add dl.ko
team join dl.ko @s
data modify entity @s Glowing set value 1b
playsound minecraft:entity.player.death master @a ~ ~ ~ 1 0.8
playsound minecraft:block.anvil.land master @a ~ ~ ~ 0.4 0.6
particle minecraft:large_smoke ~ ~1.2 ~ 0.3 0.6 0.3 0.02 20 force
