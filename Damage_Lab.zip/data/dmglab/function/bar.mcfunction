scoreboard players set #rem dl.tmp 20000
scoreboard players operation #rem dl.tmp -= @s dl.lost
execute if score #rem dl.tmp matches ..-1 run scoreboard players set #rem dl.tmp 0
scoreboard players operation #v dl.tmp = #rem dl.tmp
scoreboard players add #v dl.tmp 5
scoreboard players operation #v dl.tmp /= #10 dl.tmp
function dmglab:fmt
data modify storage dmglab:tmp hp set from storage dmglab:tmp out
execute store result storage dmglab:tmp hits int 1 run scoreboard players get @s dl.hits
data modify storage dmglab:tmp hs set value "s"
execute if score @s dl.hits matches 1 run data modify storage dmglab:tmp hs set value ""
scoreboard players operation #h dl.tmp = #rem dl.tmp
scoreboard players add #h dl.tmp 999
scoreboard players operation #h dl.tmp /= #1000 dl.tmp
execute if entity @s[tag=dl.ko] run return run execute on passengers if entity @s[tag=dl.bar] run function dmglab:bar_ko with storage dmglab:tmp
execute if score #h dl.tmp matches 0 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_0 with storage dmglab:tmp
execute if score #h dl.tmp matches 1 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_1 with storage dmglab:tmp
execute if score #h dl.tmp matches 2 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_2 with storage dmglab:tmp
execute if score #h dl.tmp matches 3 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_3 with storage dmglab:tmp
execute if score #h dl.tmp matches 4 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_4 with storage dmglab:tmp
execute if score #h dl.tmp matches 5 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_5 with storage dmglab:tmp
execute if score #h dl.tmp matches 6 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_6 with storage dmglab:tmp
execute if score #h dl.tmp matches 7 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_7 with storage dmglab:tmp
execute if score #h dl.tmp matches 8 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_8 with storage dmglab:tmp
execute if score #h dl.tmp matches 9 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_9 with storage dmglab:tmp
execute if score #h dl.tmp matches 10 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_10 with storage dmglab:tmp
execute if score #h dl.tmp matches 11 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_11 with storage dmglab:tmp
execute if score #h dl.tmp matches 12 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_12 with storage dmglab:tmp
execute if score #h dl.tmp matches 13 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_13 with storage dmglab:tmp
execute if score #h dl.tmp matches 14 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_14 with storage dmglab:tmp
execute if score #h dl.tmp matches 15 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_15 with storage dmglab:tmp
execute if score #h dl.tmp matches 16 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_16 with storage dmglab:tmp
execute if score #h dl.tmp matches 17 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_17 with storage dmglab:tmp
execute if score #h dl.tmp matches 18 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_18 with storage dmglab:tmp
execute if score #h dl.tmp matches 19 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_19 with storage dmglab:tmp
execute if score #h dl.tmp matches 20 on passengers if entity @s[tag=dl.bar] run function dmglab:bar_20 with storage dmglab:tmp
