$data merge entity @s {start_interpolation:0,interpolation_duration:3,transformation:{translation:[0f,0.45f,0f],scale:[$(lastsc)f,$(lastsc)f,$(lastsc)f]}}
