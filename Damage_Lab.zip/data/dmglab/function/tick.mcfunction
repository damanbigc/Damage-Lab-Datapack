execute as @e[type=minecraft:mannequin,tag=dl.dummy] at @s run function dmglab:dummy_tick
execute as @e[type=minecraft:text_display,tag=dl.pop] run function dmglab:pop_tick
