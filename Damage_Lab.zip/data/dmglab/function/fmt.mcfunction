scoreboard players operation #w dl.tmp = #v dl.tmp
scoreboard players operation #w dl.tmp /= #100 dl.tmp
scoreboard players operation #f dl.tmp = #v dl.tmp
scoreboard players operation #f dl.tmp %= #100 dl.tmp
scoreboard players operation #f1 dl.tmp = #f dl.tmp
scoreboard players operation #f1 dl.tmp /= #10 dl.tmp
scoreboard players operation #fr dl.tmp = #f dl.tmp
scoreboard players operation #fr dl.tmp %= #10 dl.tmp
execute store result storage dmglab:tmp w int 1 run scoreboard players get #w dl.tmp
execute store result storage dmglab:tmp f int 1 run scoreboard players get #f dl.tmp
execute store result storage dmglab:tmp f1 int 1 run scoreboard players get #f1 dl.tmp
execute if score #f dl.tmp matches 0 run function dmglab:fmt_a with storage dmglab:tmp
execute if score #f dl.tmp matches 1..9 run function dmglab:fmt_b with storage dmglab:tmp
execute if score #f dl.tmp matches 10.. if score #fr dl.tmp matches 0 run function dmglab:fmt_c with storage dmglab:tmp
execute if score #f dl.tmp matches 10.. unless score #fr dl.tmp matches 0 run function dmglab:fmt_d with storage dmglab:tmp
