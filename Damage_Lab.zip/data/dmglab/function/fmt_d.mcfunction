$data modify storage dmglab:tmp out set value "$(w).$(f)"
