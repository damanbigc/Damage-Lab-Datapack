scoreboard objectives add dl.hp dummy
scoreboard objectives add dl.prev dummy
scoreboard objectives add dl.dmg dummy
scoreboard objectives add dl.idle dummy
scoreboard objectives add dl.lost dummy
scoreboard objectives add dl.hits dummy
scoreboard objectives add dl.tmp dummy
scoreboard objectives add dl.age dummy
scoreboard players set #100 dl.tmp 100
scoreboard players set #10 dl.tmp 10
scoreboard players set #2 dl.tmp 2
scoreboard players set #1000 dl.tmp 1000
team add dl.ko
team modify dl.ko color red
